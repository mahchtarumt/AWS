<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Anime Event Payment</title>
<style>
/* Basic styling for layout */
.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.payment-form {
  background-color: #f9f9f9;
  padding: 20px;
  border-radius: 10px;
}

.payment-form label {
  display: block;
  margin-bottom: 10px;
}

.payment-form input[type="text"],
.payment-form input[type="email"],
.payment-form input[type="number"],
.payment-form select {
  width: 90%;
  padding: 8px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 14px;
}

.payment-form button {
  background-color: #007bff;
  color: #fff;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}

.payment-form button:hover {
  background-color: #0056b3;
}

/* Hide all additional fields by default */
.additional-fields {
  display: none;
}
</style>
</head>
<body>

<div class="container">
  <h2 style="text-align: center;">Anime Event Payment</h2>
  
  <div class="payment-form">
    <form id="paymentForm">
      <label for="orderSummary">Order Summary:</label>
      <p>Event: Comic Fiesta 2025</p>
      <p>Number of Tickets</p>
      <p>Adult(single day):1</p>
      <p>Adult(weekend)   :0</p>
      <p>Adult(3 days)    :0</p>
      <p>Children(single day):0</p>
      <p>Children(weekend)   :0</p>
      <p>Children(3 days)    :0</p>
      <p>Total Cost: $50.00</p>
      
      <label for="paymentMethod">Payment Method:</label>
      <select id="paymentMethod" name="paymentMethod">
        <option value="">Select Payment Method</option>
        <option value="creditCard">Credit/Debit Card</option>
        <option value="amexCard">AMEX Card</option>
        <option value="paypal">PayPal</option>
        <option value="boost">Boost Wallet</option>
        <option value="grabPay">Grab Pay Wallet</option>
        <option value="tng">TnG Wallet</option>
        <option value="advertiser">Advertiser Pass</option>
      </select>
      
      <!-- Additional fields for TnG Wallet -->
      <div class="additional-fields" id="tngFields">
        <label for="tngPhone">TnG Phone Number:</label>
        <input type="text" id="tngPhone" name="tngPhone" placeholder="Enter your TnG phone number" required>
        <label for="tngPin">TnG PIN:</label>
        <input type="password" id="tngPin" name="tngPin" placeholder="Enter your TnG PIN" required>
      </div>
      
      <!-- Additional fields for Boost Wallet -->
      <div class="additional-fields" id="boostFields">
        <label for="boostPin">Boost PIN:</label>
        <input type="password" id="boostPin" name="boostPin" placeholder="Enter your Boost PIN" required>
      </div>
      
      <!-- Additional fields for Grab Pay Wallet -->
      <div class="additional-fields" id="grabPayFields">
        <label for="grabPayPhone">Grab Pay Phone Number:</label>
        <input type="text" id="grabPayPhone" name="grabPayPhone" placeholder="Enter your Grab Pay phone number" required>
      </div>
      
      <!-- Additional fields for Advertiser Pass -->
      <div class="additional-fields" id="advertiserFields">
        <label for="advertiserCode">Advertiser Pass Code:</label>
        <input type="text" id="advertiserCode" name="advertiserCode" placeholder="Enter your Advertiser Pass code" required>
      </div>
      
      <!-- Card-related fields -->
      <div class="additional-fields" id="cardFields">
        <label for="cardNumber">Card Number:</label>
        <input type="text" id="cardNumber" name="cardNumber" placeholder="Enter your card number" required>
        
        <label for="expiryDate">Expiry Date:</label>
        <input type="text" id="expiryDate" name="expiryDate" placeholder="MM/YY" required>
        
        <label for="cvv">CVV:</label>
        <input type="text" id="cvv" name="cvv" placeholder="Enter CVV" required>
        
        <label for="billingAddress">Billing Address:</label>
        <input type="text" id="billingAddress" name="billingAddress" placeholder="Enter your billing address" required>
      </div>
      
      <button type="submit">Pay Now</button>
    </form>
  </div>
</div>

<script>
document.getElementById('paymentMethod').addEventListener('change', function() {
  var paymentMethod = this.value;
  // Show card-related fields if payment method is not chosen
  if (!paymentMethod) {
    document.getElementById('cardFields').style.display = 'block';
    return;
  }
  // Hide/show additional fields based on selected payment method
  var additionalFields = document.querySelectorAll('.additional-fields');
  additionalFields.forEach(function(field) {
    field.style.display = 'none';
  });
  if (paymentMethod === 'tng' || paymentMethod === 'boost' || paymentMethod === 'grabPay') {
    document.getElementById('cardFields').style.display = 'none';
    if (paymentMethod === 'tng') {
      document.getElementById('tngFields').style.display = 'block';
    } else if (paymentMethod === 'boost') {
      document.getElementById('boostFields').style.display = 'block';
    } else if (paymentMethod === 'grabPay') {
      document.getElementById('grabPayFields').style.display = 'block';
    }
  } else if (paymentMethod === 'advertiser') {
    document.getElementById('advertiserFields').style.display = 'block';
  } else {
    document.getElementById('cardFields').style.display = 'block';
  }
});
</script>

</body>
</html>
