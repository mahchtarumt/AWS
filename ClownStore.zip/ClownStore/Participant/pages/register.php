<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../p_asset/js/login.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../p_asset/css/profile.css">
    <link rel="stylesheet" href="../p_asset/css/memberregister.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Member Register</title>
</head>
<body>
<header>

<input type="checkbox" name="toggler" id="toggler">
<label for="toggler" class="fa fa-bars"></label>

<a href="home.php" class="logo"><span>Clown Store</span></a>

 <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
</header>
    <?php
        require_once 'helper.php';
        ?>
    <?php 
        if(!empty($_POST)){
            //user click/ submit the page
            //1.1 receive user input from form
            $memID = (trim($_POST["memberid"]));
            $name = trim($_POST["memName"]);
            $password =($_POST["memberpass"]);
            $conpassword =($_POST["memberconpass"]);
            $email =strtolower(trim($_POST["email"]));
            if(isset($_POST["memGender"])){
            $gender = trim($_POST["memGender"]);
            }else{
                $gender ="";
            }
            
            //1.2 check/validate/ verify member detail
           $error["memID"] = validateMemberID($memID);
           $error["name"] =validateMemberName($name);
           $error["gender"] = validateMemberGender($gender);
           $error["password"] = validatePassword($password,$conpassword);
           $error["email"] = validateEmail($email);
           
           //NOTE: when the $error array contains null value
           //array_filter() will remove it
           $error = array_filter($error);
           
           
           if(empty($error)){
               //GOOD, sui no error
               //Step 1: create connection 
         $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            
         //Step 2: sql statement
         $sql = "INSERT INTO Member
                 (MemberID, Password, Gender, Name, Email) 
                 VALUES(?,?,?,?,?)";
         
         $sql2 = "INSERT INTO Account
                 (MemberID, Password, Gender, Name, Email) 
                 VALUES(?,?,?,?,?)";
         //step 3:process sql
         //NOTE: $con->query($sql) <<<<<< when there is NO "?" in sql
         //NOTE: $con->prepare($sql) 
         $stmt = $con->prepare($sql);
         $stmt2 = $con->prepare($sql2);
         //Step 3.1: prepare parameter for sql with "?"
         //NOTE: s - string, d - double, i - integer, b - blob
         $stmt->bind_param("sssss",
                 $memID,$password,$gender,$name,$email);
         $stmt2->bind_param("sssss",
                 $memID,$password,$gender,$name,$email);
         //Step 3.2: execute
         $stmt->execute();
         $stmt2->execute();
         //NOTE:$stmt->affected_rows (this code will only apply to
         // CUD)
         //NOTE: $con->num_rows (how many row of records return) - R
         if($stmt2->affected_rows > 0){
             //insert successfully
             printf("
                 <div class='info'>
                 Member <b>%s</b> sucessfully registered!.
                 [ <a href='register.php'>Back to login</a> ]
                 </div>", $name);
             
         }else{
             //unable to insert
            echo "Database Error, Unable to insert. 
             Please try again!";
         }
         $con->close();
         $stmt->close();  
         $stmt2->close();   
           }
        }
        ?>
        
    <div style="margin-top: 10%;margin-left: 30%" class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Member Register</h1>
    <form method="post" class="formregister" action="">
        <?php if(!empty($error)){
            echo "<ul class='error'>";
               foreach ($error as $value){
                   echo "<li style='color:white'>$value</li>";
               }
               echo "</ul>";
        } ?>
    <table class="form">
    <tr><td><label style="color: white;" for="memberid">Member ID:</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" value="<?php  echo isset($memID)? $memID : ""; ?>" name="memberid" type="text"></td></tr>
    <tr><td><label style="color: white;" for="memberpass">Password :</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" name="memberpass" type="password"></td></tr>
    <tr><td><label style="color: white;" for="memberconpass">Confirm Password :</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" name="memberconpass" type="password"></td></tr>
    <tr><td><label style="color: white;" for="memName">Name :</label></td>
    <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" value="<?php echo isset($name)?$name:""; ?>" name="memName" type="text"></td><tr>
    <tr><td><label style="color: white;" for="memGender">Gender :</label></td>
     <td><input type="radio" name="memGender" value="M"  <?php 
                               if(isset($gender) && $gender == "M"){
                                   echo "checked";
                               }else{
                                   echo "";
                               }
                               ?>
                               />
                        <label style="color:white">Male</label>
                        <input type="radio" name="memGender" value="F" <?php 
                               if(isset($gender) && $gender == "F"){
                                   echo "checked";
                               }else{
                                   echo "";
                               }
                               ?>
                               />
                        <label style="color:white">Female</label></td><tr>
    <tr><td ><label style="color: white;" for="email">Email Address :</label></td>
        <td><input class="info" style="width: 100%;height: 20px;text-transform:none;" type="text" name="email"></td><tr>
    <tr><td colspan="2"><input style="width: 90%;height: 30px; border-radius: 1em;" type="submit" class="submit" value="Register"></td></tr>
    <tr><td colspan="2"><span class="dhac">Already have an account?</span> <a class="login" href="login.php">Sign in</a></td></tr>
    </table>
    </form>
    
    </div>
</body>
</html>