<?php 
//create function - check program
function validateEmail($email){
    if($email == NULL){
        return "Please enter your <b>Email</b>.";
    }else if(!preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/", $email)){
        return "Invalid <b>Email</b>";
    }else if(validateSameEmail($email)){ //default is == true
        return "Same <b>Email</b> detected! Please use another email.";
    }
}
function validateSameEmail($email){
    $found = false;
    
    //Step 1: create connection
    $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    //Step 1.1 clean $id, remove special character, prevent
    //sql error when exexuting sql code
   // $email = $con->real_escape_string($email);
    
    //Step 2: sql statement
     $sql ="SELECT * FROM Member WHERE Email = '$email'";
     
     //Step 3.process sql
     $result = $con->query($sql);
     
     if($result->num_rows >0){
         //result found -> SAME Email DETECTED
         $found = true;
     }else{
         //no result found -> NO PROBLEM
     }
     $result->free(); //release memory usage
     $con->close();
     
     return $found;
}


//create function - check gender
function validateMemberGender($gender){
    if($gender == null){
        return "Please select your <b>gender</b>.";
    }else if(!array_key_exists($gender, allGender())){
        return "Invalid <b>gender</b>.";
    }
}

//create function - check student name
function validateMemberName($memName){
    if($memName == null){
        return "Please enter your <b>Name</b>.";
    }else if(strlen($memName) > 30){
        return "Your <b>Name</b> should not be exceeded 30 characters.";
        
    }else if(!preg_match("/^[A-Za-z \'@\.]+$/", $memName)){
        return "Invalid <b>Name</b>.";
    }
}

function validatePassword($password,$conpassword){
    if($password == null){
        return "Please enter your <b>Password</b>.";
    }else if(strlen($password) > 30){
        return "Your <b>Password</b> exceeded 30 characters.";
    }else if(strlen($password) < 8){
        return "Your <b>Password</b> should have at least 8 characters.";
    }else if(!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,30}$/", $password)){
        return "Your <b>Password</b> must have at least one uppercase letter, at least one lowercase letter, at least one digit and only allows alphanumeric characters.";
    }else if(strcmp($password, $conpassword)!=0){
        return "Your <b>Password</b> and <b>Confirm Password</b> is not same.";
    }
}

//create function - check SAME student ID
function validateSameMemberID($memID){
    $found = false;
    
    //Step 1: create connection
    $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    //Step 1.1 clean $id, remove special character, prevent
    //sql error when exexuting sql code
    $memID = $con->real_escape_string($memID);
    
    //Step 2: sql statement
     $sql ="SELECT * FROM Account WHERE MemberID = '$memID'";
     
     //Step 3.process sql
     $result = $con->query($sql);
     
     if($result->num_rows >0){
         //result found -> SAME STUDENT ID DETECTED
         $found = true;
     }else{
         //no result found -> NO PROBLEM
     }
     $result->free(); //release memory usage
     $con->close();
     
     return $found;
}

//create function - check student ID
function validateMemberID($memID){
    if($memID == NULL){
        return "Please enter your <b>Member ID</b>.";
    }else if(!preg_match("/^[a-zA-Z0-9]{5,15}$/", $memID)){
        return "The length of <b>Member ID</b> should between 5 to 15 characters without spacing and special characters";
    }else if(validateSameMemberID($memID)){ //default is == true
        return "Same <b>Member ID</b> detected! Please try another.";
    }
}

//create function - return all gender
function allGender(){
    return array(
      'M' => 'Male',
      'F' => 'Female'
    );
}

function getUserinfo($memberid){
    $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $sql = "SELECT * FROM Member WHERE MemberID = '$memberid'";
    $result = $con->query($sql);
    
    if($row = $result->fetch_object()){
        $name = $row->Name;
        $password = $row->Password;
        $gender = $row->Gender;
        $email = $row->Email;
        $phone = $row->Phoneno;
        
    }
    $result->free();
    $con->close();
}


//declare 4 constant value that needed for DB connection
define("DB_HOST", "localhost"); //HOST mean where you keep the database
define("DB_USER", "root"); //User name in localhost
define("DB_PASS", ""); // no password 
define("DB_NAME", "assignment"); // database name

?>