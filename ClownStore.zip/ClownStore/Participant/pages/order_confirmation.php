<?php
session_start();
require_once 'databasepart.php';

$order_id = $_GET['order_id'];
$member_id = $_SESSION['memberID'];

// Fetch order details
$sql = "SELECT o.*, 
               (SELECT COUNT(*) FROM orderitems WHERE bookingid = o.bookingid) AS item_count
        FROM `order` o
        WHERE o.bookingid = ? AND o.member_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $order_id, $member_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header("Location: products.php");
    exit();
}

// Fetch order items
$sql = "SELECT oi.*, p.product_name, p.product_pic
        FROM orderitems oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.bookingid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Confirmation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-success text-white">
                <h2>Order Confirmation</h2>
            </div>
            <div class="card-body">
                <div class="alert alert-success">
                    <h4>Thank you for your order!</h4>
                    <p>Your order #<?php echo $order_id; ?> has been placed successfully.</p>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <h4>Order Details</h4>
                        <p><strong>Order Number:</strong> <?php echo $order_id; ?></p>
                        <p><strong>Order Date:</strong> <?php echo date('F j, Y, g:i a'); ?></p>
                        <p><strong>Payment Method:</strong> <?php echo ucwords(str_replace('_', ' ', $order['payment_meth'])); ?></p>
                        <p><strong>Total Amount:</strong> RM <?php echo number_format($order['total_amount'], 2); ?></p>
                    </div>
                    
                    <div class="col-md-6">
                        <h4>Items Ordered</h4>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?php echo $item['product_name']; ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>RM <?php echo number_format($item['unit_price'], 2); ?></td>
                                    <td>RM <?php echo number_format($item['subtotal'], 2); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                    <td><strong>RM <?php echo number_format($order['total_amount'], 2); ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <a href="products.php" class="btn btn-primary">Continue Shopping</a>
                    <a href="order_history.php" class="btn btn-secondary">View Order History</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>