<?php
session_start();
require_once 'databasepart.php'; 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Shopping Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        header{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: #fff;
            padding: 0.7rem 9%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index:1000;
            box-shadow: 0.5rem 1rem rgba(0, 0, 0, 0.1);
        }

        header .logo{
            font-size: 3rem;
            color: #333;
            font-weight: bolder;
        }

        header .logo span{
            color: peru;
        }

        header .homehead a{
            font-size: 2rem;
            padding: 0 1.5rem;
            color: #666;

        }

        header .homehead a:hover{
            color: peru;
        }
        header .icon {
            padding-top: 0.5rem;
        }

        header .icon a{
            font-size: 1.5rem;
            color: peachpuff;
            margin-left: 1.5rem;
            float: right;
        }

        header .icon .ccontainer .shopping img{
            max-width: 3.5rem;
            padding: 0;
            margin: 0;
            margin-left: 1rem;
            float: right;
            bottom: 0;
        }

        header .icon a:hover{
            color: firebrick;
        }

        .icon{
            display: flex;
        }

        header #toggler{
            display: none;
        }

        header .fa-bars{
          font-size:3rem;
          color :#333;
          border-radius: 0.5rem;
          padding: 1rem 1rem;
          cursor: pointer;
          border: .1rem solid rgba(0, 0, 0, 0.3);  
          display: none;
        }
        
        footer{
            font-style: italic;
            font-weight: bold;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            background-color: rgba(255,255,255,0.1);
            position: relative;
            top: 100%;
            z-index: 5000;
            left: 5.28%;
            max-width: 94.7%;
        }

        .footerNav ul li{
            list-style-type: none;
        }

        .footerContain{
            width: 100%;
            padding: 70px 30px 20px;
        }

        .socialIcon{
            box-shadow: 0 0.5rem 0.8rem rgba(0,0,0,0.9);
            color: white;
            display: flex;
            justify-content: center;
            background-color: white;
            border-radius: 50px;
        }

        .socialIcon a{
            background-color: white;
            padding: 10px;
            text-decoration: none;

        }

        .socialIcon a i{
            margin: 10px;
            padding: 10px;
            max-width: 100px;
            font-size: 3em;
            color: black;
            opacity: 0.9;
        }

        .socialIcon a:hover{
            color: white;
            transition: 0.5s;
        }

        .socialIcon a:hover i{
            color: white;
            transition: 0.5s;
            background-color: black;
            border-radius: 50%;
        }

        .footerNav{
            margin: 30px 0;
        }

        .footerNav ul{
            display: flex;
            justify-content: center;
        }

        .footerNav ul li a{
            color: white;
            margin: 20px;
            text-decoration: none;
            font-size: 1.5em;
            opacity: 0.4;
            transition: 0.5s;
        }

        .footerNav ul li a:hover{
            opacity: 1;
        }

        .footerBottom{
            padding: 2%;
            text-align: center;
            font-size: 2.5rem;
        }

        .footerBottom p{
            color: rgb(117, 121, 236);
        }

        .designer{
            opacity: 0.7;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: bold;
            margin: 0;
        }
    </style>
</head>
<body >
    <header>

        <input type="checkbox" name="toggler" id="toggler">
        <label for="toggler" class="fa fa-bars"></label>

        <a href="home.php" class="logo"><span>Clown Store</span></a>

        <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
    </header><br><br><br>
    
    <div class="container" style="max-width: 1200px; margin-top: 100px; margin-bottom: 50px;">
        <h2 class="mb-4" style="font-size: 28px; color: #333;">Your Shopping Cart</h2>
        
        <?php if (empty($_SESSION['cart'])): ?>
            <div class="empty-cart text-center" style="min-height: 400px; display: flex; flex-direction: column; justify-content: center; align-items: center; background: white; border-radius: 10px; padding: 40px; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
                <i class="fas fa-shopping-cart fa-4x mb-4" style="color: #ddd;"></i>
                <h3 class="mb-3" style="font-size: 24px; font-weight: 600;">Your cart is empty</h3>
                <p class="text-muted mb-4" style="font-size: 16px;">Looks like you haven't added any items yet</p>
                <a href="products.php" class="btn btn-primary btn-lg px-4" style="font-size: 16px; background-color: #ff6b6b; border-color: #ff6b6b;">
                    <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                </a>
            </div>
        <?php else: ?>
            <form method="post" action="cart.php">
                <table class="table table-hover align-middle" style="background-color: white; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05); font-size: 15px;">
                    <thead style="background: linear-gradient(135deg, #ff6b6b 0%, #ff5252 100%); color: white;">
                        <tr>
                            <th style="font-size: 16px; font-weight: 500;">Product</th>
                            <th style="font-size: 16px; font-weight: 500;">Price</th>
                            <th style="font-size: 16px; font-weight: 500;">Quantity</th>
                            <th style="font-size: 16px; font-weight: 500;">Total</th>
                            <th style="font-size: 16px; font-weight: 500;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total = 0;
                        foreach ($_SESSION['cart'] as $item): 
                            $subtotal = $item['product_price'] * $item['quantity'];
                            $total += $subtotal;
                        ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="/ClownStore/Participant/p_asset/images/<?php echo $item['product_pic']; ?>" style="width: 100px; height: 100px; object-fit: contain; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);" class="me-3">
                                    <span style="font-weight: 600; color: #333;"><?php echo $item['product_name']; ?></span>
                                </div>
                            </td>
                            <td style="font-size: 15px;">RM <?php echo number_format($item['product_price'], 2); ?></td>
                            <td>
                                <input type="number" name="quantities[<?php echo $item['product_id']; ?>]" 
                                       value="<?php echo $item['quantity']; ?>" min="1" style="width: 80px; text-align: center; border: 1px solid #ddd; border-radius: 5px; padding: 5px; font-size: 15px;">
                            </td>
                            <td style="font-weight: bold; font-size: 15px;">RM <?php echo number_format($subtotal, 2); ?></td>
                            <td>
                                <a href="cart.php?remove=<?php echo $item['product_id']; ?>" class="btn btn-danger btn-sm" style="font-size: 14px;">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <tr style="background-color: #f8f9fa;">
                            <td colspan="3" class="text-end" style="font-weight: bold; font-size: 16px;">Total:</td>
                            <td style="font-weight: bold; color: #ff6b6b; font-size: 16px;">RM <?php echo number_format($total, 2); ?></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
                
                <div class="d-flex justify-content-between mb-5">
                    <a href="products.php" class="btn btn-outline-primary px-4" style="font-size: 15px;">
                        <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                    </a>
                    <div>
                        <button type="submit" name="update_cart" class="btn btn-secondary me-2 px-4" style="font-size: 15px;">
                            <i class="fas fa-sync-alt me-2"></i>Update Cart
                        </button>
                        <a href="<?php 
                                    if(isset($_SESSION['memberID'])) {
                                        echo 'checkout.php';
                                    } else {
                                        $_SESSION['redirect'] = 'checkout.php';
                                        echo 'checkout.php';
                                    }
                                ?>" class="btn btn-success px-4" style="font-size: 15px; background-color: #06d6a0; border-color: #06d6a0;">
                            <i class="fas fa-credit-card me-2"></i>Proceed to Checkout
                        </a>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
    
    <?php include 'footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>