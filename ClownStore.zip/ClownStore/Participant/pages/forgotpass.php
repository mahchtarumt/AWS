<?php
if(isset($_GET["send"])){
    $memberID = $_GET["memID"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <script src="../p_asset/js/login.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../p_asset/css/memberlogin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../p_asset/css/memberforgotpass.css">
    
</head>
<body>
<header>

<input type="checkbox" name="toggler" id="toggler">
<label for="toggler" class="fa fa-bars"></label>

<a href="home.php" class="logo"><span>Clown Store</span></a>

 <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
</header>
    <div style="margin-top: 10%;margin-left: 30%" class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Forgot Password</h1>
    <form method="post" class="formforgot" action="mail.php">
        <table style="line-height: 39px;" class="form">
        <tr><td><label style="color: white;" required for="memID">Member ID:</label></td>
        <td><input class="info" style="width: 95%;text-transform: none" type="text" required id="memID" name="MemberID"></td>
        <td><input style="width: 80px;" type="submit" class="submit" name="send" value="Send"></td></tr>
    </table>
    </form>   
</div>
</body>
</html>
