<?php
session_start();
require_once 'databasepart.php';

if (!isset($_SESSION['memberID'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['order_id'])) {
    header("Location: order_history.php");
    exit();
}

$order_id = $_GET['order_id'];
$member_id = $_SESSION['memberID'];

// Fetch order details
$sql = "SELECT o.*, 
               DATE_FORMAT(o.created_at, '%Y-%m-%d') AS order_date
        FROM `order` o
        WHERE o.bookingid = ? AND o.member_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $order_id, $member_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header("Location: order_history.php");
    exit();
}

// Fetch order items
$sql = "SELECT oi.*, p.product_name, p.product_pic
        FROM orderitems oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.bookingid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">
                <h2>Order Details</h2>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h4>Order Information</h4>
                        <p><strong>Order Number:</strong> <?php echo $order['bookingid']; ?></p>
                        <p><strong>Order Date:</strong> <?php echo $order['order_date']; ?></p>
                        <p><strong>Payment Method:</strong> <?php echo ucwords(str_replace('_', ' ', $order['payment_meth'])); ?></p>
                    </div>
                    <div class="col-md-6 text-end">
                        <h4>Order Total</h4>
                        <p><strong>Total Items:</strong> <?php echo $order['qty']; ?></p>
                        <p><strong>Total Amount:</strong> RM <?php echo number_format($order['total_amount'], 2); ?></p>
                    </div>
                </div>
                
                <h4>Items Ordered</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td>
                                <img src="/ClownStore/Participant/p_asset/images/<?php echo $item['product_pic']; ?>" width="50" height="50">
                                <?php echo $item['product_name']; ?>
                            </td>
                            <td>RM <?php echo number_format($item['unit_price'], 2); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>RM <?php echo number_format($item['subtotal'], 2); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Total:</strong></td>
                            <td><strong>RM <?php echo number_format($order['total_amount'], 2); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
                
                <div class="text-center mt-4">
                    <a href="order_history.php" class="btn btn-secondary">Back to Order History</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>