<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anime Society</title>
    <link rel="stylesheet" href="../p_asset/css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100..900&display=swap" rel="stylesheet">
    <style>
        .cart-count {
            background: #ffb02f;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            position: relative;
            top: -10px;
            right: 5px;
        }
    </style>
</head>
<body>
<header>
    <input type="checkbox" name="toggler" id="toggler">
    <label for="toggler" class="fa fa-bars"></label>

    <a href="home.php" class="logo"><span>Clown Store</span></a>

    <div class="icon">
        <a href="home.php"><i class="fa fa-home"></i></a>
        <a href="./products.php"><i class="fa fa-book"></i></a>
        <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
        </a>
        <a href="./login.php"><span id="login"><?php echo isset($_SESSION['memberID']) ? 'Profile' : 'Login'; ?></span></a>
        <a href="./profile.php" class="fa fa-user"></a>
    </div>
</header>