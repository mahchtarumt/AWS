<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>CLown Store</title>
        <link rel="stylesheet" href="../p_asset/css/home.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@100..900&display=swap" rel="stylesheet">
    </head>

<body>
    <header>

        <input type="checkbox" name="toggler" id="toggler">
        <label for="toggler" class="fa fa-bars"></label>

        <a href="home.php" class="logo"><span>Clown Store</span></a>

        <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
    </header>
    

    <section class="home" id="home">
        <div class="content">
            <h3>Clown Store</h3>
            <span>The Best Graduation Present</span>
            <p>Buy your graduation present through our website now!</p>
            <a href="products.php" id ="h" class="btn">Order Now</a>
        </div>
    </section>

<section class="about" id="about">
    <h1 class="heading"><span>about</span> us</h1>
    <div class="row">
        <div class="video-container">
            <img src="../p_asset/images/graduationimg.jpg" width="600" height="400" alt="Graduation Image">
            <h3>Best Clown Store</h3>
        </div>

        <div class="content">
            <h3>Clown Store</h3>
            <p>Welcome to Anime society! Our mission is  to provide high-quality, affordable, and fun graduation essentials—from flowers and gowns to keepsake gifts—making your milestone moments even more special. We’re here to help graduates and their loved ones create unforgettable memories with a touch of happiness!</p>
            <p>At Clown Store, buyers can find everything they need to celebrate graduation - from fresh flowers and stylish caps & gowns to cute teddy bears and unique keepsake gifts, all at affordable prices with cheerful service!</p>
        </div>
    </div>
</section>


<section class="contact" id="contact">
    <h1 class="heading"><span>Feed</span>Back</h1>
<?php
    if(!empty($_POST)){
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = $_POST["phone"];
    $message = trim($_POST['message']);

    $db_server = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "assignment";
    $con = new mysqli($db_server, $db_user, $db_pass, $db_name);

   
    $sql = "INSERT INTO feedback (name, email, phone, message) VALUES (?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('ssss', $name, $email, $phone, $message);
    $stmt->execute();

    $stmt->close();
    $con->close();
}
?>
    <div class="row">
    <form action="" method="post">
    <input type="text" name="name" id="name" placeholder="name" class="box" required>
    
    <input type="email" placeholder="email" name="email" id="email" class="box" required>

    <input type="tel" name="phone" id="phone" placeholder="phone" class="box" pattern="[0-9]{3}[0-9]{7}" title="Phone number must be 11 digits and start with 0" required>
    
    <textarea name="message" id="message" cols="30" rows="10" placeholder="message" class="box" required></textarea>
    
    <input type="submit" value="send message" id ="h" class="btn" onclick="return receive();">
</form>


        <div class="image">
            <img src="../p_asset/images/feedback.jpg" alt="my wife">
        </div>

    </div>
</section>

<footer>
    <div class="footerContain">
        <div class="socialIcon">
            <a href=""><i class="fa fa-facebook" style="width:5rem;text-align: center;"></i></a>
            <a href=""><i class="fa fa-instagram"></i></a>
            <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-wechat"></i></a>
            <a href=""><i class="fa fa-youtube"></i></a>
        </div>
        
        <div class="footerBottom">
            <p>Copyright &copy; 2024; Desgined By <span class="designer">Clown Store</span></p>
        </div>
    </div>
</footer>
<script>
function receive() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var phone = document.getElementById('phone').value;

    
    var emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
   
    var phonePattern = /^[0-9]{3}[0-9]{7}$/;


    if(name === "" || email === "" || phone === "") {
        alert("Please fill all required fields.");
        return false;
    }

    if(!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return false;
    }

    if(!phonePattern.test(phone)) {
        alert("Please enter a valid phone number (e.g., 0114702903).");
        return false;
    }

    alert("We Have Received Your Feedback. Thank You!");
    return true; 
}


</script>
</body>



</html>