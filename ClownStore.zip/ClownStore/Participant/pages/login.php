<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="../p_asset/js/login.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../p_asset/css/memberlogin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Member Login</title>
</head>
<body>
<header>

<input type="checkbox" name="toggler" id="toggler">
<label for="toggler" class="fa fa-bars"></label>

<a href="home.php" class="logo"><span>Clown Store</span></a>

        <div class="icon">
            <a href="home.php"><i class="fa fa-home"></i></a>
            <a href="./products.php"><i class="fa fa-book"></i></a>
            <a href="./login.php"><span id="login">Login</span></a>
            <a href="./view_cart.php"><i class="fa fa-shopping-cart"></i> 
            <?php if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                <span class="cart-count"><?php echo array_sum(array_column($_SESSION['cart'], 'quantity')); ?></span>
            <?php endif; ?>
            <a href="./profile.php" class="fa fa-user"></a>
        </div>
</header>
    
    <?php
        require_once 'helper.php';
        ?>
    <?php 
     if(!empty($_POST)){
            //user click/ submit the page
            //1.1 receive user input from form
            $loginid = $_POST["memberid"];
            $password =($_POST["memberpass"]);
            if(strcmp($loginid,"ST001")==0 && strcmp($password,"Cclcc5030")==0){
                header("Location:../../Admin_Panel/admin_panel/dashboard.php");
            }
            $con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $sql ="SELECT * FROM Member WHERE MemberID = '$loginid'";
            $result = $con->query($sql);
            if($result->num_rows ==1){
               $row = $result->fetch_object();
               if(strcmp($password,$row->Password)==0){
                    session_start();
                    $_SESSION["memberID"] = $loginid;

                    // Check for redirect URL
                    if(isset($_SESSION['redirect'])) {
                        $redirect = $_SESSION['redirect'];
                        unset($_SESSION['redirect']);
                        header("Location: $redirect");
                    } else {
                        header("Location: profile.php");
                    }
                    exit();
                }
            }
            else{
                $loginerror = "MemberID not found!";
            }
     }
     
    ?>
    <div style="margin-top:10%;margin-left: 30% " class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Member Login</h1>
    <form method="post" class="formlogin" action="">
        <?php
        if(!empty($loginerror)){
            echo "<p style='color:white'>{$loginerror}</p>";
        }
        ?>
    <label style="color: white;" for="memberid">Member ID :</label>
    <input required class="info" style="width: 60%;height: 20px;text-transform:none;" name="memberid" type="text"><br><br>
    <label style="color: white;" for="memberpass">Password&nbsp;&nbsp; &nbsp;:</label>
    <input required class="info" style="width: 60%;height: 20px;text-transform:none;" name="memberpass" type="password"><br>
    <input type="submit" class="submit" value="Sign in"><br>
    <a class="forgot" href="forgotpass.php">Forgot Password?</a><br><br>
    <span class="dhac">Doesn't have an account?</span> <a class="regis" href="register.php">Register</a>
    </form>
    
    </div>
</body>
</html>