<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <script src="../p_assets/js/login.js" type="text.javascript"></script>
    <link rel="stylesheet" href="resetpass.css">
</head>
<body>
    <div class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Reset Password</h1>
    <form method="get" class="formreset" action="Participant/pages/login.php">
        <table style="line-height: 39px;" class="form">
        <tr><td><label style="color: white;" for="newpass">New Password:</label></td>
        <td><input class="info" type="password" required name="newpass" id="newpass"></td></tr>
        <tr><td><label style="color: white;" for="comfirmpass">Confirm Password:</label></td>
        <td><input class="info" type="password" required id="confirmpass" name="confirmpass"></td></tr>
        <tr><td style="text-align: center;" colspan="2"><input type="submit" class="submit" name="submit" value="Confirm"></td></tr>
    </table>
    </form>   
</div>
</body>
</html>