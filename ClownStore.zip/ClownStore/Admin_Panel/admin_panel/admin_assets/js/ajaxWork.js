

function showEvents(){  
    $.ajax({
        url:"./adminView/viewAllEvents.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}
function showFigures(){  
    $.ajax({
        url:"./adminView/viewFigures.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}
function showTrailor(){  
    $.ajax({
        url:"./adminView/viewAllTrailor.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}
function showFeedbacks(){  
    $.ajax({
        url:"./adminView/viewFeedbacks.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function showHomePage(){  
    $.ajax({
        url:"./adminView/viewHomePage.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}
function showNews(){  
    $.ajax({
        url:"./adminView/viewNews.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function showEventNote(){  
    $.ajax({
        url:"./adminView/viewEventNotes.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function showStaffinfo(){  
    $.ajax({
        url:"./adminView/viewStaffinfo.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}



function showCustomers(){
    $.ajax({
        url:"./adminView/viewCustomers.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function showBookings(){
    $.ajax({
        url:"./adminView/viewAllBooking.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}


