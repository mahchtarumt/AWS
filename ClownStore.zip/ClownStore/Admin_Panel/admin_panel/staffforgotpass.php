<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <script src="./admin_assets/js/login.js" type="text/javascript"></script>
   <link rel="stylesheet" href="./admin_assets/css/staffforgotpass.css"/>
</head>
<body>
    <div class="formtable">
    <button class="back" onclick="goback()">Back</button>
    <h1 class="title">Forgot Password</h1>
    <form method="get" class="formforgot" action="../../resetpassword.php">
        <table style="line-height: 39px;" class="form">
        <tr><td><label style="color: white;" for="email">Email:</label></td>
        <td><input class="info" style="width: 95%" type="email" required id="email" name="email"></td>
        <!--<tr><td><label style="color: white;" for="favcolor">Favourite Colour:</label></td>
        <td><input class="info" type="text" required id="favcolor" name="favcolor"></td><br></tr>
        <tr><td><label style="color: white;" for="primschool">Primary School:</label></td>
        <td><input class="info" type="primschool" required id="primschool" name="primschool"></td>-->
        <td><button onclick="sendemail()" class="submit">Send</button></td></tr>
    </table>
    </form>   
</div>
</body>
</html>
<script>
    function sendemail(){
        alert("A reset password link had sent to your email. Please check it now")
    }
    </script>