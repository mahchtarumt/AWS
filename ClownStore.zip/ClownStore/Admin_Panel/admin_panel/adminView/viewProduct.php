<?php
 $conn = new mysqli('localhost', 'root', '', 'assignment');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// Fetch all products from database
$sql = "SELECT * FROM products ORDER BY product_id DESC";
$result = $conn->query($sql);

// Handle product deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $delete_id);
    
    if ($stmt->execute()) {
        $_SESSION['message'] = "Product deleted successfully";
        header("Location: viewProduct.php");
        exit();
    } else {
        $_SESSION['error'] = "Error deleting product";
    }
}

// Handle bulk actions
if (isset($_POST['bulk_action'])) {
    if (!empty($_POST['selected_products'])) {
        $product_ids = implode(",", $_POST['selected_products']);
        
        switch ($_POST['bulk_action']) {
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM products WHERE product_id IN ($product_ids)");
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Selected products deleted successfully";
                } else {
                    $_SESSION['error'] = "Error deleting products";
                }
                break;
                
            case 'activate':
                $stmt = $conn->prepare("UPDATE products SET status = 'active' WHERE product_id IN ($product_ids)");
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Selected products activated";
                } else {
                    $_SESSION['error'] = "Error activating products";
                }
                break;
                
            case 'deactivate':
                $stmt = $conn->prepare("UPDATE products SET status = 'inactive' WHERE product_id IN ($product_ids)");
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Selected products deactivated";
                } else {
                    $_SESSION['error'] = "Error deactivating products";
                }
                break;
        }
        
        header("Location: viewProduct.php");
        exit();
    } else {
        $_SESSION['error'] = "No products selected";
        header("Location: viewProduct.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - View Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --admin-primary: #4e73df;
            --admin-secondary: #1cc88a;
            --admin-danger: #e74a3b;
            --admin-warning: #f6c23e;
        }
        
        body {
            background-color: #f8f9fc;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--admin-primary) 10%, #224abe 100%);
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            background-color: #f8f9fc;
            border-bottom: 1px solid #e3e6f0;
            font-weight: 600;
        }
        
        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }
        
        .status-active {
            color: var(--admin-secondary);
        }
        
        .status-inactive {
            color: var(--admin-danger);
        }
        
        .btn-action {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .search-box {
            max-width: 300px;
        }
        
        .bulk-actions {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar bg-dark">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="dashboard.php">
                                <i class="fas fa-fw fa-tachometer-alt mr-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="viewProduct.php">
                                <i class="fas fa-fw fa-boxes mr-2"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="viewCustomers.php">
                                <i class="fas fa-fw fa-users mr-2"></i> Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="viewStaffInfo.php">
                                <i class="fas fa-fw fa-user-tie me-2"></i> Staff
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="/AnimeSociety/Participant/pages/logout.php">
                                <i class="fas fa-fw fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Product Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="addProduct.php" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus mr-2"></i> Add New Product
                        </a>
                    </div>
                </div>

                <!-- Messages -->
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['message']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['error']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-table mr-2"></i>All Products</span>
                    </div>
                    <div class="card-body">
                        <form method="post" action="viewProduct.php">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover" width="100%" cellspacing="0">
                                    <thead class="thead-light">
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="10%">Image</th>
                                            <th>Name</th>
                                            <th>Category</th>
                                            <th>Price(RM)</th>
                                            <th>Stock</th>
                                            <th width="15%">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($result->num_rows > 0): ?>
                                            <?php $rowNumber = 1; ?>
                                            <?php while ($product = $result->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo $rowNumber++; ?></td>
                                                    <td>
                                                         <img src="/ClownStore/Participant/p_asset/images/<?php echo htmlspecialchars($product['product_pic']); ?>" alt="<?php echo $product['product_name']; ?>" class="product-img">
                                                    </td>
                                                    <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($product['category']); ?></td>
                                                    <td><?php echo number_format($product['product_price'], 2); ?></td>
                                                    <td><?php echo $product['stock_quantity']; ?></td>
                                                    <td>
                                                        <a href="editProduct.php?id=<?php echo $product['product_id']; ?>" class="btn btn-sm btn-action btn-warning" title="Edit">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="viewProduct.php?delete_id=<?php echo $product['product_id']; ?>" class="btn btn-sm btn-action btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this product?');">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="8" class="text-center">No products found</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Select all checkboxes
        document.getElementById('selectAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('input[name="selected_products[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
        
        // Confirm before bulk actions
        document.querySelector('form').addEventListener('submit', function(e) {
            const bulkAction = this.querySelector('select[name="bulk_action"]').value;
            const checkedBoxes = this.querySelectorAll('input[name="selected_products[]"]:checked');
            
            if (bulkAction && checkedBoxes.length === 0) {
                e.preventDefault();
                alert('Please select at least one product');
                return false;
            }
            
            if (bulkAction === 'delete') {
                if (!confirm(`Are you sure you want to delete ${checkedBoxes.length} selected product(s)?`)) {
                    e.preventDefault();
                    return false;
                }
            }
        });
    </script>
</body>
</html>