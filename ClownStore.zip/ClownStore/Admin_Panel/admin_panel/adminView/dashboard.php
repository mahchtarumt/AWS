<?php
 $conn = new mysqli('localhost', 'root', '', 'assignment');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get statistics
$stats = [];

// Total products
$sql = "SELECT COUNT(*) as total_products FROM products";
$result = $conn->query($sql);
$stats['total_products'] = $result->fetch_assoc()['total_products'];

// Total members
$sql = "SELECT COUNT(*) as total_members FROM member";
$result = $conn->query($sql);
$stats['total_members'] = $result->fetch_assoc()['total_members'];

// Total orders
$sql = "SELECT COUNT(*) as total_orders FROM `order`";
$result = $conn->query($sql);
$stats['total_orders'] = $result->fetch_assoc()['total_orders'];

// Recent orders
$sql = "SELECT o.bookingid, m.Name as customer_name, o.total_amount, o.created_at 
        FROM `order` o
        JOIN member m ON o.member_id = m.MemberID
        ORDER BY o.created_at DESC LIMIT 5";
$recent_orders = $conn->query($sql);

// Low stock products
$sql = "SELECT product_name, stock_quantity FROM products WHERE stock_quantity < 10 ORDER BY stock_quantity ASC LIMIT 5";
$low_stock = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --admin-primary: #4e73df;
            --admin-secondary: #1cc88a;
            --admin-danger: #e74a3b;
            --admin-warning: #f6c23e;
            --admin-info: #36b9cc;
        }
        
        body {
            background-color: #f8f9fc;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--admin-primary) 10%, #224abe 100%);
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            background-color: #f8f9fc;
            border-bottom: 1px solid #e3e6f0;
            font-weight: 600;
        }
        
        .stat-card {
            border-left: 0.25rem solid;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card.primary {
            border-left-color: var(--admin-primary);
        }
        
        .stat-card.success {
            border-left-color: var(--admin-secondary);
        }
        
        .stat-card.danger {
            border-left-color: var(--admin-danger);
        }
        
        .stat-card.warning {
            border-left-color: var(--admin-warning);
        }
        
        .stat-card .stat-icon {
            font-size: 2rem;
            opacity: 0.3;
        }
        
        .stat-card .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .stat-card .stat-label {
            text-transform: uppercase;
            font-weight: 600;
            font-size: 0.8rem;
            color: #5a5c69;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .recent-order {
            transition: all 0.3s;
        }
        
        .recent-order:hover {
            background-color: #f8f9fa;
        }
        
        .low-stock-item {
            color: var(--admin-danger);
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar bg-dark">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="dashboard.php">
                                <i class="fas fa-fw fa-tachometer-alt mr-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="viewProduct.php">
                                <i class="fas fa-fw fa-boxes mr-2"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="viewCustomers.php">
                                <i class="fas fa-fw fa-users mr-2"></i> Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="viewStaffInfo.php">
                                <i class="fas fa-fw fa-user-tie me-2"></i> Staff
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="/AnimeSociety/Participant/pages/logout.php">
                                <i class="fas fa-fw fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group mr-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card primary h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="stat-label">Total Products</div>
                                        <div class="stat-value"><?php echo $stats['total_products']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-boxes stat-icon text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card success h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="stat-label">Total Members</div>
                                        <div class="stat-value"><?php echo $stats['total_members']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users stat-icon text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card warning h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="stat-label">Total Orders</div>
                                        <div class="stat-value"><?php echo $stats['total_orders']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-shopping-cart stat-icon text-warning"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>

                <!-- Recent Orders and Low Stock -->
                <div class="row">
                    <!-- Recent Orders -->
                    <div class="col-lg-8 mb-4">
                        <div class="card shadow h-100">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold">Recent Orders</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-borderless">
                                        <thead>
                                            <tr>
                                                <th>Order ID</th>
                                                <th>Customer</th>
                                                <th>Amount (RM)</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if ($recent_orders && $recent_orders->num_rows > 0): ?>
                                                <?php while ($order = $recent_orders->fetch_assoc()): ?>
                                                    <tr class="recent-order">
                                                        <td>#<?php echo $order['bookingid']; ?></td>
                                                        <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                                        <td><?php echo number_format($order['total_amount'], 2); ?></td>
                                                        <td><?php echo date('d M Y', strtotime($order['created_at'])); ?></td>
                                                    </tr>
                                                <?php endwhile; ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="5" class="text-center">No recent orders</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Low Stock Products -->
                    <div class="col-lg-4 mb-4">
                        <div class="card shadow h-100">
                            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                <h6 class="m-0 font-weight-bold">Low Stock Products</h6>
                                <a href="viewProduct.php" class="btn btn-sm btn-primary">View All</a>
                            </div>
                            <div class="card-body">
                                <?php if ($low_stock && $low_stock->num_rows > 0): ?>
                                    <div class="list-group">
                                        <?php while ($product = $low_stock->fetch_assoc()): ?>
                                            <a href="editProduct.php?id=<?php echo $product['product_id']; ?>" class="list-group-item list-group-item-action">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($product['product_name']); ?></h6>
                                                    <span class="low-stock-item"><?php echo $product['stock_quantity']; ?> left</span>
                                                </div>
                                                <small>Click to restock</small>
                                            </a>
                                        <?php endwhile; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-success">
                                        All products have sufficient stock
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>