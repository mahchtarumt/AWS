<?php
$conn = new mysqli('localhost', 'root', '', 'assignment');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$product = [
    'product_name' => '',
    'product_desc' => '',
    'product_price' => '',
    'stock_quantity' => '0',
    'category' => '',
    'product_pic' => ''
];
$errors = [];
$categories = []; // Will be populated from database

// Get existing categories from database
$category_query = "SELECT DISTINCT category FROM products";
$category_result = $conn->query($category_query);
while ($row = $category_result->fetch_assoc()) {
    $categories[] = $row['category'];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize input
    $product['product_name'] = trim($_POST['product_name']);
    $product['product_desc'] = trim($_POST['product_desc']);
    $product['product_price'] = trim($_POST['product_price']);
    $product['stock_quantity'] = trim($_POST['stock_quantity']);
    $product['category'] = trim($_POST['category']);
    
    // Validation
    if (empty($product['product_name'])) {
        $errors['product_name'] = "Product name is required";
    }
    
    if (empty($product['product_price']) || !is_numeric($product['product_price']) || $product['product_price'] <= 0) {
        $errors['product_price'] = "Valid price is required";
    }
    
    if (!is_numeric($product['stock_quantity']) || $product['stock_quantity'] < 0) {
        $errors['stock_quantity'] = "Valid stock quantity is required";
    }
    
    if (empty($product['category'])) {
        $errors['category'] = "Category is required";
    }
    
    // Handle file upload
    if (empty($_FILES['product_image']['name'])) {
        $errors['product_image'] = "Product image is required";
    } else {
        $target_dir = "uploads/products/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_name = basename($_FILES['product_image']['name']);
        $target_file = $target_dir . uniqid() . '_' . $file_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        // Check if image file is an actual image
        $check = getimagesize($_FILES['product_image']['tmp_name']);
        if ($check === false) {
            $errors['product_image'] = "File is not an image";
        }
        
        // Check file size (max 2MB)
        if ($_FILES['product_image']['size'] > 2000000) {
            $errors['product_image'] = "Image must be less than 2MB";
        }
        
        // Allow certain file formats
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($imageFileType, $allowed_types)) {
            $errors['product_image'] = "Only JPG, JPEG, PNG & GIF files are allowed";
        }
        
        // If no errors, upload file
        if (empty($errors['product_image'])) {
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
                $product['product_pic'] = $target_file;
            } else {
                $errors['product_image'] = "Error uploading file";
            }
        }
    }
    
    // Insert into database if no errors
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO products 
            (product_name, product_desc, product_price, stock_quantity, category, product_pic) 
            VALUES (?, ?, ?, ?, ?, ?)");
        
        $stmt->bind_param("ssdiss", 
            $product['product_name'],
            $product['product_desc'],
            $product['product_price'],
            $product['stock_quantity'],
            $product['category'],
            $product['product_pic']
        );
        
        if ($stmt->execute()) {
            $_SESSION['message'] = "Product added successfully";
            header("Location: viewProduct.php");
            exit();
        } else {
            $errors['database'] = "Error adding product: " . $conn->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --admin-primary: #4e73df;
            --admin-secondary: #1cc88a;
            --admin-danger: #e74a3b;
        }
        
        body {
            background-color: #f8f9fc;
        }
        
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            background-color: #f8f9fc;
            border-bottom: 1px solid #e3e6f0;
            font-weight: 600;
        }
        
        .product-image-preview {
            max-width: 200px;
            max-height: 200px;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 5px;
            background: white;
        }
        
        .required-field::after {
            content: " *";
            color: var(--admin-danger);
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--admin-primary) 10%, #224abe 100%);
            min-height: 100vh;
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar bg-dark">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link text-white" href="dashboard.php">
                                <i class="fas fa-fw fa-tachometer-alt mr-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="viewProduct.php">
                                <i class="fas fa-fw fa-boxes mr-2"></i> Products
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="viewCustomers.php">
                                <i class="fas fa-fw fa-users mr-2"></i> Users
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="viewStaffInfo.php">
                                <i class="fas fa-fw fa-user-tie me-2"></i> Staff
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="admin_logout.php">
                                <i class="fas fa-fw fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add New Product</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="viewProduct.php" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-arrow-left mr-2"></i> Back to Products
                        </a>
                    </div>
                </div>

                <!-- Error messages -->
                <?php if (!empty($errors['database'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $errors['database']; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="card mb-4">
                    <div class="card-header">
                        <i class="fas fa-plus-circle mr-2"></i>Product Details
                    </div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row mb-4">
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label for="product_name" class="form-label required-field">Product Name</label>
                                        <input type="text" class="form-control <?php echo isset($errors['product_name']) ? 'is-invalid' : ''; ?>" 
                                               id="product_name" name="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>">
                                        <?php if (isset($errors['product_name'])): ?>
                                            <div class="invalid-feedback"><?php echo $errors['product_name']; ?></div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="product_desc" class="form-label">Description</label>
                                        <textarea class="form-control" id="product_desc" name="product_desc" rows="3"><?php echo htmlspecialchars($product['product_desc']); ?></textarea>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="product_price" class="form-label required-field">Price (RM)</label>
                                            <input type="number" step="0.01" class="form-control <?php echo isset($errors['product_price']) ? 'is-invalid' : ''; ?>" 
                                                   id="product_price" name="product_price" value="<?php echo htmlspecialchars($product['product_price']); ?>">
                                            <?php if (isset($errors['product_price'])): ?>
                                                <div class="invalid-feedback"><?php echo $errors['product_price']; ?></div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="stock_quantity" class="form-label">Stock Quantity</label>
                                            <input type="number" class="form-control <?php echo isset($errors['stock_quantity']) ? 'is-invalid' : ''; ?>" 
                                                   id="stock_quantity" name="stock_quantity" value="<?php echo htmlspecialchars($product['stock_quantity']); ?>">
                                            <?php if (isset($errors['stock_quantity'])): ?>
                                                <div class="invalid-feedback"><?php echo $errors['stock_quantity']; ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="category" class="form-label required-field">Category</label>
                                            <input type="text" class="form-control <?php echo isset($errors['category']) ? 'is-invalid' : ''; ?>" 
                                                   id="category" name="category" list="categories" value="<?php echo htmlspecialchars($product['category']); ?>">
                                            <datalist id="categories">
                                                <?php foreach ($categories as $cat): ?>
                                                    <option value="<?php echo htmlspecialchars($cat); ?>">
                                                <?php endforeach; ?>
                                            </datalist>
                                            <?php if (isset($errors['category'])): ?>
                                                <div class="invalid-feedback"><?php echo $errors['category']; ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="product_image" class="form-label required-field">Product Image</label>
                                        <div class="mb-2">
                                            <img id="imagePreview" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" alt="Product Image Preview" class="product-image-preview mb-2" style="display: none;">
                                        </div>
                                        <input type="file" class="form-control <?php echo isset($errors['product_image']) ? 'is-invalid' : ''; ?>" 
                                               id="product_image" name="product_image" accept="image/*" required>
                                        <?php if (isset($errors['product_image'])): ?>
                                            <div class="invalid-feedback"><?php echo $errors['product_image']; ?></div>
                                        <?php endif; ?>
                                        <small class="text-muted">Max 2MB (JPG, PNG, GIF)</small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save mr-2"></i> Add Product
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Preview image before upload
        document.getElementById('product_image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('imagePreview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        });
    </script>
</body>
</html>