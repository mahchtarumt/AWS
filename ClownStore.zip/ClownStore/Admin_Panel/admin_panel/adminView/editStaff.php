<?php
// Function to sanitize user input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$errors = array(); // Array to store validation errors

// Check if form submitted via POST method
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize user input
    $fname = isset($_POST['fname']) ? sanitizeInput($_POST['fname']) : '';
    $lname = isset($_POST['lname']) ? sanitizeInput($_POST['lname']) : '';
    $gender = isset($_POST['gender']) ? sanitizeInput($_POST['gender']) : '';
    $email = isset($_POST['email']) ? sanitizeInput($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? sanitizeInput($_POST['phone']) : '';
    $birthday = isset($_POST['birthday']) ? sanitizeInput($_POST['birthday']) : '';
    $country = isset($_POST['country']) ? sanitizeInput($_POST['country']) : '';
    $id = isset($_GET['id']) ? sanitizeInput($_GET['id']) : '';
    $oimg = isset($_POST['oimg']) ? sanitizeInput($_POST['oimg']) : ''; // old image path
    $position = isset($_POST['position']) ? sanitizeInput($_POST['position']) : ''; // position value

    // Validate required fields
    if (empty($fname)) {
        $errors[] = "First name is required.";
    }
    if (empty($lname)) {
        $errors[] = "Last name is required.";
    }
    if (empty($gender)) {
        $errors[] = "Gender is required.";
    }
    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }
    if (empty($phone)) {
        $errors[] = "Phone number is required.";
    } elseif (!preg_match('/^\d{10}$/', $phone)) {
        $errors[] = "Phone number must be 10 digits without dashes.";
    }
    if (empty($birthday)) {
        $errors[] = "Birthday is required.";
    }
    if (empty($country)) {
        $errors[] = "Country is required.";
    }

    // Process form if no validation errors
    if (empty($errors)) {
        $file_name = $_FILES['image']['name'];
        $tempname = $_FILES['image']['tmp_name'];
        if (!empty($file_name)) { // Check if a new file is uploaded
            $folder = 'admin_assets/images/' . $file_name;
            if (move_uploaded_file($tempname, $folder)) {
                // File uploaded successfully
                $img_path = $file_name;
            } else {
                // File upload failed, retain the old image path
                $img_path = $oimg; // Use old image if upload fails
            }
        } else {
            // No file was uploaded
            $img_path = $oimg; // Retain old image path if no new file
        }

        // Update database
        $db_server = "localhost";
        $db_user = "root";
        $db_pass = "";
        $db_name = "assignment";
        $con = new mysqli($db_server, $db_user, $db_pass, $db_name);
        $query = mysqli_query($con, "UPDATE staff SET first_name='$fname', last_name='$lname', gender='$gender', email='$email', phone='$phone', birthday='$birthday', country='$country', img_path='$img_path' WHERE staff_id='$id'");

        if ($query) {
            // Update successful
            printf("
                            <div class='info'>
                            Staff <b>S%d</b> has been updated.
                            <button style=\"background-color:gray;width:5.2em;\"><a href=\"dashboard.php\" style=\"color:white;font-weight:bold;\">Back TO Dashboard</a></button>
                            </div>
                        ",$id);
                        $show = "SELECT * FROM staff where staff_id = '$id'";
                        $result = $con->query($show);
                        if($row = $result->fetch_object())
                        {
                            //read records from the each field
                            $fname=$row->first_name;
                            $lname=$row->last_name;
                            $gender=$row->gender;
                            $email=$row->email;
                            $phone=$row->phone;
                            $position=$row->position;
                            $birth=$row->birthday;
                            $country=$row->country;
                            $oimg=$row->img_path;
                            $id=$row->staff_id;
                                    
                        }
                        else
                        {
                            //no record selected
                            echo '
                                <div class="error">
                                Database error. Record Not Found.
                                <div>
                                ';
                        }
                        $result->free();
        } else {
            // Update failed
            echo '<div class="error">Error, Unable to update!</div>';
        }
        $con->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Staff Information</title>
 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="admin_assets/css/style.css"/>

<style>
    h1{
        text-align: center;
        color: white;
        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        text-decoration: underline;
    }
    body{
        background-color: lightsalmon;
    }
   tr{
    height:50x;
   }
   span{
    color: black;
    font-weight: bold;
    text-align: center;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
   }
   tr,td,th{
    margin-left: 3%;
    margin-right: 0;
    padding-left: 0;
    padding-right: 0;
   
   }
</style>
</head>
<body>
<h1>Edit Staff Information</h1>
        <?php
        
        //retrieve student records from database
        //based on student id on URL
        if($_SERVER['REQUEST_METHOD']=='GET')
        {
            //GET METHOD
            //get student id from url
            $id = $_GET['id'];
            
            //step 1: connect with database
            $db_server="localhost";
            $db_user="root";
            $db_pass="";
            $db_name="assignment";
            $con="";
            $con = new mysqli($db_server,$db_user,$db_pass, $db_name);
            
            //construct sql statement
            
            $sql = "SELECT * FROM staff WHERE staff_id = '$id'";

            
            //excute sql query
            $result = $con->query($sql);
            
            if($row = $result->fetch_object())
            {
                //read records from the each field
                $fname=$row->first_name;
                $lname=$row->last_name;
                $gender=$row->gender;
                $email=$row->email;
                $phone=$row->phone;
                $position=$row->position;
                $birthday=$row->birthday;
                $country=$row->country;
                $oimg=$row->img_path;
                $id=$row->staff_id;
                
                        
            }
            else
            {
                //no record selected
                echo '
                    <div class="error">
                    Database error. Record Not Found.
                    <div>
                    ';
            }
            
            $result->free();
            $con->close();
        }
       
        ?>
        
        <table>
            <form action="" method="POST" enctype="multipart/form-data">
                <tr>
                    <td><span>Staff ID :</span></td>
                    <td><?php echo "S{$id}"; ?></td>
                </tr>

                <tr>
                    <td><span>Existing Icon :</span></td>
                    <td><img height='100px' src="admin_assets/images/<?php echo $oimg?>"></td> 
                </tr>

                <tr>
                    <td><span>New Icon :</span></td>
                    <td><input type="file" name="image" id="image" require  ></td>
                </tr>


                <tr>
                    <td><span>First Name :</span></td>
                    <td><input type="text" name="fname" value="<?php echo $fname;?>" require maxlength="15" style="width:20em;"></td>
                </tr>

                <tr>
                    <td><span>Last Name :</span></td>
                    <td><input type="text" name="lname" value="<?php echo $lname;?>" require style="width:20em;"></td>
                </tr>

                <tr>
                    <td><span>Gender :</span></td>
                    <td>
                        <select name="gender" id="gender" required style="width:20em; height: 4em;">
                            <option value="">Select Gender</option>
                            <option value="M" <?php echo ($gender == 'M' ? 'selected' : ''); ?>>Male</option>
                            <option value="F" <?php echo ($gender == 'F' ? 'selected' : ''); ?>>Female</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td><span>Email :</span></td>
                    <td><input type="email" name="email" value="<?php echo $email;?>" require style="width:20em;"></td>
                </tr>
                <tr>
                    <td><span>Phone :</span></td>
                    <td><input type="tel" name="phone" value="<?php echo $phone;?>" require style="width:20em;"></td>
                </tr>
                <tr>
                    <td><span>Position :</span></td>
                    <td><?php echo $position; ?></td>
                </tr>

                <tr>
                    <td><span>Birthday :</span></td>
                    <td><input type="date" name="birthday" value="<?php echo $birthday; ?>" required style="width:20em;"></td>
                </tr>


                <tr>
                    <td><span>Country :</span></td>
                    <td>
                        <select name="country" id="country" required style="width:20em; height: 4em;">
                            <option value="">Select Country</option>
                            <option value="USA" <?php echo ($country == 'USA' ? 'selected' : ''); ?>>United States</option>
                            <option value="MLY" <?php echo ($country == 'MLY' ? 'selected' : ''); ?>>Malaysia</option>
                            <option value="UK" <?php echo ($country == 'UK' ? 'selected' : ''); ?>>United Kingdom</option>
                        </select>
                    </td>



                </tr>

                <input type="hidden" name="oimg" value="<?php echo $oimg;?>">
                <input type="hidden" name="position" value="<?php echo $position;?>">

                <tr>
                <input style="background-color: gray;font-size:1.5em;color:white;width:4em;margin-left:3%;" type="submit" value="Update" name="update" />
                </tr>
              
            </form>
        </table>
        
        <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
</body>
</html>